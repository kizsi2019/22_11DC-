---
name: Request for Help
about: Guidance on using Requests.

---

Please refer to our [Stack Overflow tag](https://stackoverflow.com/questions/tagged/python-requests) for guidance.
